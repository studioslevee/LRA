# LRA Constructors — Client Review Prototype

Astro-based responsive one-page prototype using the approved warm beige / navy / rugged editorial direction.

## Run locally

1. `npm install`
2. `npm run dev`
3. Open the local URL Astro displays.

## Share through Netlify

Push this directory to GitHub, then import the repository in Netlify. Build command: `npm run build`. Publish directory: `dist`. The included `netlify.toml` contains these settings.

## Review limitations

- Concept images are crops of the approved design mockup and must be replaced with licensed photographs of real LRA projects before launch.
- Contact form is deliberately nonfunctional.
- Projects and service copy need client verification.
- The current preview is a scrolling single-page experience; detailed pages, CMS, and backend come later.
